package com.tima.bengalibamboozler;

import android.content.Intent;
import android.os.Bundle;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;


import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import java.util.*;


public class MainActivity extends AppCompatActivity {

    private EditText txtIn;
    private EditText txtOut;
    private TextView title;
    private Button encode;
    private Button decode;

        // The original list of characters to be encoded
    ArrayList<Character> alphabet =
    new ArrayList<Character>(Arrays.asList(
                        'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j',
                        'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's',
                        't', 'u', 'v', 'w', 'x', 'y', 'z'));

    ArrayList<Character> code = new ArrayList<Character>(Arrays.asList(
                'আ',
                'ব',
                'ক',
                'ড',
                'ই',
                'ফ',
                'ঘ',
                'গ',
                'হ',
                'ই',
                'চ',
                'ক',
                'ল',
                'ম',
                'ন',
                'ও',
                'প',
                'ক', //q
                'র',
                'স',
                'ট',
                'উ',
                'ভ'
                ,'ঊ'
                ,'ছ'
                ,'য'
                ,'ঝ'
                ));

    // produce an encoded String from the given String
    String encode(String message) {
            return exchangeChar(message, this.alphabet, this.code);
    }

    // produce a decoded String from the given String
    String decode(String message) {
            //you should complete this method
            return exchangeChar(message, this.code, this.alphabet);
    }

    //takes the index of a list of characters and finds their index equivalent in
    //alphabet -> coder
    String exchangeChar(String message,
                        ArrayList<Character> alphabet, ArrayList<Character> coder) {
        String newCode = "";
        for (int i = 0; i < message.length(); i = i + 1) {
            //gets the index of a character
            int charInd = alphabet.indexOf(message.charAt(i));
            // gets the character based on index
            Character newCharacter = coder.get(charInd);
            //
            newCode = newCode + newCharacter;
            //adds to string
        }
        return newCode;
        //returns modified string
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        txtIn = (EditText)findViewById(R.id.txtIn);
        txtIn = (EditText)findViewById(R.id.txtIn);
        encode = (Button)findViewById(R.id.encode);
        decode = (Button)findViewById(R.id.encode2);

        encode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = txtIn.getText().toString();
                String newCode = encode(message);
                txtOut.setText(newCode);
            }
        });

        decode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = txtIn.getText().toString();
                String newCode = decode(message);
                txtOut.setText(newCode);
            }
        });




        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
